//Tyler Shinkle Assignment #1 ITDEV 140-200
package shinkle_mybmi;

import java.util.Scanner;

public class View {
    
    //OBJECT INSTANTIATIONS
    Scanner keyboard = new Scanner(System.in);
    //VARIABLE DECLARATIONS
    public String userInput;
    public static String stars="\t************************************************************";
    
    public void intro()
    {
        //DISPLAY INTRO
        printStars();
        formatOutput("APPLICATION TITLE: My BMI");
        formatOutput("AUTHOR: Tyler Shinkle");
        formatOutput("CLASS: ITDEV 140-200");
        formatOutput("ASSIGNMENT: #1");
        formatOutput("DESCRIPTION: The user will be prompted to first input their height in inches, then their weight in pounds. Once the data is gathered their BMI will be calculated and displayed along with a message.");
        formatOutput("!!Enter 'quit' at anytime to exit this application!!");
        printStars();
    }    
    
    //prompt to start
    public String begin()
    {
        System.out.print("\tEnter 'begin' to start or 'quit' to exit: ");
        userInput=keyboard.next();
        return userInput;
    }
    
    //prompts for metrics.
    public String gatherHeight()
    {
        System.out.print("\tPlease enter your height as a whole number of inches: ");
        userInput=keyboard.next();
        return userInput;
    }
    
    public String gatherWeight()
    {
        System.out.print("\tPlease enter your weight as a whole number of pounds: ");
        userInput=keyboard.next();
        return userInput;
    }
    
    //display bmi and range.
    public void displayResults(float bmi, String status)
    {
        printStars();
        formatOutput("Your BMI is: "+bmi+".");
        formatOutput("You're considered to be "+status+".");
        printStars();
    }
    
    //ask to continue or quit.
    public String continuePrompt()
    {
        System.out.print("\tPlease enter 'continue' to do more calculations or 'quit' \n\tto quit:");
        userInput=keyboard.next();
        return userInput;
    }
    
    public void invalidInput()
    {
        printStars();
        formatOutput("That input is invalid!");
        printStars();
    }
    
    public void outro()
    {
        printStars();
        formatOutput("Goodbye!");
        printStars();
    }
    
    //output stars for borders
    public void printStars()
    {
        System.out.println(stars);
    }
    
    //format output
    public void formatOutput(String s)
    {        
        //reference value of last character making sure it is a space
        int currentEnd=stars.length()-5;
        
        if(s.length()>currentEnd)
        {
           
            //find the longest substring whose
            //last character is a space.
            while(s.charAt(currentEnd)!=' ')
            {
                currentEnd--;
            }
            
            //output this substring
            System.out.println(String.format("%-"+(stars.length()-1)+"s","\t* "+s.substring(0,currentEnd))+"*");
            
            //call this function again with the remainder of 
            //our initial string ignoring the space at the beginning.
            formatOutput(s.substring(currentEnd+1));
        }
        else
        {
            System.out.println(String.format("%-"+(stars.length()-1)+"s","\t* "+s)+"*");
        }
    }
}
