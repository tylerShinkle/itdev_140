//Tyler Shinkle Assignment #1 ITDEV 140-200
package shinkle_mybmi;

public class Shinkle_MyBMI {

    //OBJECT INSTANTIATIONS
    static View view = new View();
    static Controller control = new Controller();
    //VARIABLE DECLARATIONS
    static boolean run = true;
    
    public static void main(String[] args) {
        //displat intro
        view.intro();
        //continue calling bmi method until false is returned.
        while(run)
        {
            run=control.bmi();
        }
        //say goodbye.
        view.outro();
    }
    
}
