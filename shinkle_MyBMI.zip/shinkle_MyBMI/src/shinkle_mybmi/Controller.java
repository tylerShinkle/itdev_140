//Tyler Shinkle Assignment #1 ITDEV 140-200
package shinkle_mybmi;

public class Controller {
    
    //OBJECT INSTANTIATIONS
    static View view = new View();
    //VARIABLE DECLARATIONS
    //value to hold userInput.
    String userInput="valid";
    //value to cycle through necessary steps.
    int step = 0;
    //variables related to bmi
    int height;
    int weight;
    float yourBMI;
    String status;
    
    //entry from main begins here.
    public boolean bmi()
    {
        //continue through steps as long as 'quit' is not passed in by user.
        while(!userInput.toLowerCase().equals("quit"))
        {
            switch(step)
            {
                //only begin with this the first go around, otherwise step is reset to 1.
                //ask user if they are ready or would like to quit and proceed accordingly.
                case 0:
                    userInput=view.begin();
                    if(!userInput.toLowerCase().equals("begin") && !userInput.toLowerCase().equals("quit"))
                    {
                        view.invalidInput();
                        break;
                    }
                    step++;
                    break;
                //gather height.
                case 1:
                    userInput=view.gatherHeight().toLowerCase();
                    if(!userInput.equals("quit"))
                    {
                        try
                        {
                            height=Integer.parseInt(userInput);
                        }
                        
                        catch(Exception e)
                        {
                            view.invalidInput();
                            break;
                        }
                        
                    }
                    step++;
                    break;
                //gather weight
                case 2: 
                    userInput=view.gatherWeight();
                    if(!userInput.equals("quit"))
                    {
                        try
                        {
                            weight=Integer.parseInt(userInput);
                        }
                        
                        catch(Exception e)
                        {
                            view.invalidInput();
                            break;
                        }
                        
                    }
                    step++;
                    break;
                //calculate BMI and display message.
                case 3:
                    yourBMI=calcBMI(height,weight);
                    if(yourBMI<18.5)
                    {
                        status="underweight";
                    }
                    else if(yourBMI>25)
                    {
                        status="overweight";
                    }
                    else
                    {
                        status="normal";
                    }
                    view.displayResults(yourBMI, status);
                    step++;
                    break;
                //ask if they'd like to continue.
                case 4:
                    userInput=view.continuePrompt();
                    if(!userInput.toLowerCase().equals("quit") && !userInput.toLowerCase().equals("continue"))
                    {
                        view.invalidInput();
                        break;
                    }
                    if(userInput.toLowerCase().equals("continue"))
                    {
                        //reset step to 1 then enter from main.
                        step=1;
                        return true;
                    }
                    break;
                default:
                    return false;
            }
        }
        return false;
    }
    
    //calculate BMI
    public float calcBMI(int h, int w)
    {
        float result;
        float fw=(float) w;
        float fh=(float) h;
        result=fw*703/(fh*fh);
        return result;
    }
    
}